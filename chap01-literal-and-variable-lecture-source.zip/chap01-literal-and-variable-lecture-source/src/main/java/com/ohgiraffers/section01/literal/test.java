package com.ohgiraffers.section01.literal;

public class test {
    public static void main(String[]args){

      double height=181.2;
      int myHeight=(int)height;
        System.out.println("height:"+myHeight);





    }
}
