package com.ohgiraffers.section01.literal;

public class Application01 {
    public static void main(String[]args){
        System.out.println(123);
        System.out.println(1.23);
        System.out.println('a'); //문자 형태의 값은 '홀따옴표'('single-quotation')로 감싸줘야한다
        //System.out.println('ab');//두개 이상의 문자는 문자로 취급하지않음
        //System.out.println(''); 싱글 쿼테이션 안에는 빈칸X
        System.out.println('1');
        System.out.println("안녕하세여");
        System.out.println("123");
        System.out.println("");
        System.out.println("a");

        System.out.println(true);
        System.out.println(false);
    }
}
