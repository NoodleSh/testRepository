package com.ohgiraffers.stock.run;

import com.ohgiraffers.stock.view.stockMenu;

public class Application {
    public static void main(String[] args) {
        new stockMenu().mainPage();
    }
}
